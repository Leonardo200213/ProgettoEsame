$('.carousel').carousel({
  interval: 2000;
  keyboard:true;
})